// pages/info/updateInfo.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  /**
   * 页面的初始数据
   * 修改详细信息
   */
  data: {
    info:{}
  },
  // 提交按钮，修改数据
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value),
    db.collection('KaoYan_info').doc(e.detail.value.id).update({
      data: {
        name: e.detail.value.name,
        sex: e.detail.value.sex,
        tel: e.detail.value.tel,
        qq: e.detail.value.qq,
        wechat: e.detail.value.wechat,
        blog: e.detail.value.blog,
        github: e.detail.value.github,
      },
      success: function () {
        setTimeout(function () {
          wx.showToast({
            title: '数据修改成功',
          })
        }, 2000)
        //返回上一页
        wx.navigateBack({ changed: true });
      },
      fail: function () {
        console.log("详细信息数据修改失败")
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("这里是updateInfo")
    console.log("学号为"+options.id)
    let that = this
    db.collection('KaoYan_info').doc(options.id).get({
      success: function (res) {
        that.setData({
          info: res.data
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})