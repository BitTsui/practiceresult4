// pages/info/info.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  /**
   * 页面的初始数据
   * 根据学号获取学生详细信息
   */
  data: {
    info:{}
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("这里是info，页面加载")
    console.log(options.id)
    let that = this
    db.collection('KaoYan_info').doc(options.id).get({
      success: function (res) {
        that.setData({
          info: res.data
        })
      },
      fail:function(){
        console.log("无详细数据")
        wx.showModal({
          title: '无学生详细信息',
          content: '添加学生详细信息？',
          success(res) {
            if (res.confirm) {
              wx.navigateTo({
                url: './addInfo?id=' + options.id,
              })
            } else if (res.cancel) {
              //返回上一页
              wx.navigateBack({changed:true});
            }
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("info显示")
    // this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})