// pages/student/student.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  /**
  * 页面的初始数据
    studentList：根据year查询到的学生基本信息数据
  */
  data: {
    // KaoYan_student: '未获取',
    year: '2019',
    studentList: [],
  },
  // 点击姓名，查看学生基本信息
  NamePress: function (e) {
    wx.navigateTo({
      url: '/pages/student/student?id=' + e.currentTarget.dataset.variable,
    })
  },
  // 点击分数，查看学生成绩信息
  ScorePress: function (e) {
    wx.navigateTo({
      url: '/pages/score/score?id=' + e.currentTarget.dataset.variable,
    })
  },
  // js中实现绑定的长按点击事件
  // 长按姓名，可以进行修改添加操作
  // 需要管理员权限
  NamelongPress: function (e) {
    console.log(e.currentTarget.dataset.variable)
    wx.showActionSheet({
      itemList: ['修改基本信息', '修改详细信息'],
      success(res) {
        console.log(res.tapIndex)
        if(res.tapIndex==0){
          console.log("点击的是修改基本信息")
          wx.navigateTo({
            url: '../student/updateStudent?id=' + e.currentTarget.dataset.variable,
          })
        } else if (res.tapIndex == 1){
          console.log("点击的是修改详细信息")
          wx.navigateTo({
            url: '../info/updateInfo?id=' + e.currentTarget.dataset.variable,
          })
        }
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
    // wx.showModal({ //使用模态框提示用户进行操作
    //   title: '警告',
    //   content: '你将清空小程序本地所有缓存！',
    //   success: function (res) {
    //     if (res.confirm) { //判断用户是否点击了确定
    //       wx.clearStorageSync();
    //     }
    //   }
    // })
  },
  // 长按主页中的分数，修改成绩信息
  ScorelongPress: function (e) {
    console.log(e.currentTarget.dataset.variable)
    wx.showModal({
      title: '修改成绩信息',
      content: '修改成绩信息？',
      success(res) {
        if (res.confirm) {
          wx.navigateTo({
            url: '../score/updateScore?id=' + e.currentTarget.dataset.variable,
          })
        }
      }
    })
    // wx.showActionSheet({
    //   itemList: ['修改基本信息', '修改详细信息'],
    //   success(res) {
    //     console.log(res.tapIndex)
    //     if (res.tapIndex == 0) {
    //       console.log("点击的是修改基本信息")
    //       wx.navigateTo({
    //         url: '../student/updateStudent?id=' + e.currentTarget.dataset.variable,
    //       })
    //     } else if (res.tapIndex == 1) {
    //       console.log("点击的是修改详细信息")
    //       wx.navigateTo({
    //         url: '../info/updateInfo?id=' + e.currentTarget.dataset.variable,
    //       })
    //     }
    //   },
    //   fail(res) {
    //     console.log(res.errMsg)
    //   }
    // })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log("页面已加载")
    db.collection('KaoYan_student').where({
      "score_year": that.data.year,
    }).orderBy('score_total', 'desc').get({
      success: function (res) {
        console.log(res.data)
        // let test = res.data.sort(res.data.)
        that.setData({
          studentList: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("student页面显示")
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log("student页面隐藏")
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("用户下拉")
    var that = this
    db.collection('KaoYan_student').where({
      "score_year": that.data.year,
    }).orderBy('score_total', 'desc').get({
      success: function (res) {
        console.log(res.data)
        // let test = res.data.sort(res.data.)
        that.setData({
          studentList: res.data
        })
        wx.showToast({
          title: '已刷新',
        })
      }
    })
    setTimeout(function () {
      // 这里写刷新要调用的函数，比如：
      wx.stopPullDownRefresh();
    }, 500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})