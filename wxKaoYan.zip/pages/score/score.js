// pages/score/score.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  /**
   * 页面的初始数据
   * 获取学生成绩信息
   */
  data: {
    score:{
      _id:"",
      name:"",
      politics_score:-1,
      english_subject:"英语",
      english_score:-1,
      math_subject:"数学",
      math_score:-1,
      major_subject:"专业课",
      major_score:-1,
      score_total: -1,
      score_year:2019
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("这里是score，页面加载")
    console.log(options.id)
    let that = this
    db.collection('KaoYan_score').doc(options.id).get({
      success: function (res) {
        that.setData({
          score: res.data
        })
      },
      fail: function () {
        console.log("无成绩数据")
        wx.showModal({
          title: '无学生成绩信息',
          content: '添加学生成绩信息？',
          success(res) {
            if (res.confirm) {
              wx.navigateTo({
                url: './addScoreSubject?id=' + options.id,
              })
            } else if (res.cancel) {
              //返回上一页
              wx.navigateBack({ changed: true });
            }
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})