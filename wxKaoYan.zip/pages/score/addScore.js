// pages/score/addScore.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  /**
   * 页面的初始数据
   * 添加初试单科成绩
   */
  data: {
    score:{}
  },
  // 提交按钮
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    db.collection('KaoYan_score').doc(e.detail.value.id).update({
      data: {
        politics_score: e.detail.value.politics_score,
        english_score: e.detail.value.english_score,
        math_score: e.detail.value.math_score,
        major_score: e.detail.value.major_score,
        score_total:  parseInt(e.detail.value.politics_score)+
                      parseInt(e.detail.value.english_score)+
                      parseInt(e.detail.value.math_score)+
                      parseInt(e.detail.value.major_score)
      },
      success: function () {
        setTimeout(function () {
          wx.showToast({
            title: '成绩数据添加成功',
          })
        }, 2000)
        db.collection('KaoYan_student').doc(e.detail.value.id).update({
          data: {
            score_total: parseInt(e.detail.value.politics_score) +
              parseInt(e.detail.value.english_score) +
              parseInt(e.detail.value.math_score) +
              parseInt(e.detail.value.major_score)
          }
        })
        //返回上一页
        wx.navigateBack({
          delta:3
        });
      },
      fail: function () {
        console.log("成绩信息数据修改失败")
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("这里是addScore，页面加载")
    console.log(options.id)
    let that = this
    db.collection('KaoYan_score').doc(options.id).get({
      success: function (res) {
        console.log(res.data.english_subject + "成绩：" + res.data.english_score)
        // 如果没有成绩信息
        if (typeof res.data.english_score =="undefined"){
          that.setData({
            score: res.data
          })
        // 如果已经有成绩信息，提示并返回上一页
        }else{
          setTimeout(function () {
            wx.showToast({
              title: '已有成绩信息',
            })
          }, 2000)
          wx.navigateBack({
            delta:1
          })
        }
        
      }
    })
    db.collection('KaoYan_score').doc(options.id).get({
      success: function (res) {
        
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})