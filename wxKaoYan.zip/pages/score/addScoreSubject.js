// pages/score/addScoreSubject.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  /**
   * 页面的初始数据
   * 添加初试考试科目信息
   */
  data: {
    englishItems:[
      { name: '英语一', checked: 'true' },
      { name: '英语二' },
      { name: '日语' },
      { name: '俄语' }
    ],
    mathItems: [
      {name: '数学一',checked:'true'},
      {name: '数学二'},
      {name: '数学三'}
    ],
    score:{}
  },
  //英语考试科目，单选按钮
  englishRadioChange: function(e) {
    console.log('英语科目：', e.detail.value)
  },
  // 数学考试科目，单选按钮
  mathRadioChange: function (e) {
    console.log('数学科目：', e.detail.value)
  },
  // 提交按钮
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if (e.detail.value.major_subject==""){
      wx.showToast({
        title: "请输入专业课科目",
      })
    // 如果信息输入正确，则插入数据库
    }else{
      db.collection('KaoYan_score').add({
        data: {
          _id: e.detail.value.id,
          name: e.detail.value.name,
          english_subject:e.detail.value.english_subject,
          math_subject:e.detail.value.math_subject,
          major_subject:e.detail.value.major_subject,
          score_year: e.detail.value.score_year
        },
        success: function () {
          wx.showToast({
            title: "插入成功"
          }),
          wx.showModal({
            title: '添加成绩信息',
            content: '继续添加成绩信息？',
            success(res) {
              if (res.confirm) {
                wx.navigateTo({
                  url: './addScore?id=' + e.detail.value.id,
                })
              } else if (res.cancel) {
                //返回上一页
                wx.navigateBack({ changed: true });
              }
            }
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("这里是addScoreSubject，页面加载")
    console.log(options.id)
    let that = this
    db.collection('KaoYan_student').doc(options.id).get({
      success: function (res) {
        that.setData({
          score: {
            _id: res.data._id,
            name:res.data.name,
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})