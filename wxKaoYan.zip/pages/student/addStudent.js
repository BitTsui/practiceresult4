// pages/student/addStudent.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({
  // 添加学生基本信息（不包括报考信息）
  data: {
    error:"",
    success:"",
    sch: "中原工学院",
    college: "软件学院",
    major: "软件工程",
    score_year: "2019",
  },
  formSubmit: function (e) {
    //如果id未输入，不能插入学生信息，并提示
    if (e.detail.value.id == "" ){
      this.setData({
        success: "",
        error:"请输入学号"
      })
    } else if (e.detail.value.name == ""){
      this.setData({
        success: "",
        error: "请输入姓名"
      })
    }else{
      console.log('form发生了submit事件，携带数据为：', e.detail.value), 
      db.collection('KaoYan_student').add({
        data: {
          _id: e.detail.value.id,
          name: e.detail.value.name,
          sex: e.detail.value.sex,
          sch: e.detail.value.sch,
          college: e.detail.value.college,
          major: e.detail.value.major,
          clazz: e.detail.value.clazz,
          register_sch: e.detail.value.register_sch,
          register_major: e.detail.value.register_major,
          register_direction: e.detail.value.register_direction,
          score_total: e.detail.value.score_total,
          score_year: e.detail.value.score_year,
        }
      })
      this.setData({
        success: wx.showToast({
          title: "插入成功",
        })
      })
    }
  },
  formReset: function () {
    console.log('form发生了reset事件')
    this.setData({
      success: "",
      error: "",
      sch: "中原工学院",
      college: "软件学院",
      major: "软件工程",
      score_year: "2019",
    })
  },
  formClean:function(){
    console.log('form发生了clean事件')
    this.setData({
      success: "",
      error: "",
      sch: "",
      college: "",
      major: "",
      score_year: "",
    })
  },
  /**
   * 页面的初始数据
   */
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})