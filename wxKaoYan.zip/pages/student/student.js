// pages/student/student.js
wx.cloud.init({
  env: 'wx-tsui-e1xd2'
})
const db = wx.cloud.database({
  env: 'wx-tsui-e1xd2'
})
Page({

  /**
   * 页面的初始数据
   * 获取学生基本信息
   */
  data: {
    // _id:"",
    // name:"",
    // sex:"",
    // sch:"",
    // college:"",
    // major:"",
    // clazz: "",
    // register_sch: "",
    // register_major: "",
    // register_direction:"",
    // score_total:"",
    // score_year:"",
    student:{}
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("这里是student")
    let that = this
    db.collection('KaoYan_student').doc(options.id).get({
      success: function (res) {
        console.log(typeof res.data._id)
        that.setData({
          student:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})